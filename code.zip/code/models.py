from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import json

database = SQLAlchemy()


class User(UserMixin, database.Model):
    id = database.Column(database.Integer, primary_key=True)
    username = database.Column(database.String(50), unique=True, nullable=False)
    password = database.Column(database.String(100), nullable=False)
    email = database.Column(database.String(100), unique=True)
    created_at = database.Column(database.DateTime, default=datetime.utcnow)
    is_active = database.Column(database.Boolean, default=True)

# Прогресс пользователя
    def get_progress(self):
        progress = UserProgress.query.filter_by(user_id=self.id).first()
        return progress.score if progress else 0

    def to_dict(self):
        return {'id': self.id, 'username': self.username, 'email': self.email}


class ChineseWord(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    chinese_text = database.Column(database.String(100), nullable=False)
    pinyin = database.Column(database.String(100), nullable=False)
    translation = database.Column(database.String(100), nullable=False)
    example_sentence = database.Column(database.String(300))
    example_translation = database.Column(database.String(300))
    difficulty = database.Column(database.Integer, default=1)
    category = database.Column(database.String(50))

    def to_dict(self):
        return {
            'id': self.id,
            'chinese': self.chinese_text,
            'pinyin': self.pinyin,
            'translation': self.translation,
            'difficulty': self.difficulty,
            'category': self.category
        }


class UserProgress(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    user_id = database.Column(database.Integer, database.ForeignKey('user.id'), nullable=False)
    word_id = database.Column(database.Integer, database.ForeignKey('chinese_word.id'))
    score = database.Column(database.Integer, default=0)
    correct_attempts = database.Column(database.Integer, default=0)
    total_attempts = database.Column(database.Integer, default=0)
    last_practiced = database.Column(database.DateTime, default=datetime.utcnow)

# Процент правильных ответов
    def success_rate(self):
        if self.total_attempts == 0:
            return 0
        return (self.correct_attempts / self.total_attempts) * 100

# Обновление статистики после ответа
    def update_score(self, is_correct):
        self.total_attempts += 1
        if is_correct:
            self.correct_attempts += 1
            self.score += 10
        self.last_practiced = datetime.utcnow()


class History(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    title = database.Column(database.String(200), nullable=False)
    file_name = database.Column(database.String(200))
    content = database.Column(database.Text)
    dynasty = database.Column(database.String(100))
    year = database.Column(database.Integer)
    uploaded_by = database.Column(database.Integer, database.ForeignKey('user.id'))
    uploaded_at = database.Column(database.DateTime, default=datetime.utcnow)
    view_count = database.Column(database.Integer, default=0)

    def increment_views(self):
        self.view_count += 1

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'dynasty': self.dynasty,
            'year': self.year,
            'file_name': self.file_name
        }