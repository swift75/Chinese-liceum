from flask import Flask, request, render_template, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import random
import os

app = Flask(__name__)
app.secret_key = "super-secret-key-change-in-production"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///chinese.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

database = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"


# Пользователь
class User(UserMixin, database.Model):
    id = database.Column(database.Integer, primary_key=True)
    username = database.Column(database.String(50), unique=True, nullable=False)
    password = database.Column(database.String(100), nullable=False)

    def __repr__(self):
        return f"<User {self.username}>"


# Слова
class ChineseWord(database.Model):
    id = database.Column(database.Integer, primary_key=True)
    chinese_text = database.Column(database.String(100), nullable=False)
    translation = database.Column(database.String(100), nullable=False)
    pinyin = database.Column(database.String(100))

    def __repr__(self):
        return f"<Word {self.chinese_text}>"


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# Главная
@app.route("/")
def home():
    return render_template("home.html")


# Регистрация
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash("Пользователь с таким именем уже существует", "danger")
            return redirect(url_for("register"))

        new_user = User(username=username, password=password)
        database.session.add(new_user)
        database.session.commit()

        flash("Регистрация успешна! Теперь войдите в систему", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


# Вход в систему
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            flash(f"Добро пожаловать, {username}!", "success")
            return redirect(url_for('vocabulary'))
        else:
            flash("Неверное имя пользователя или пароль", "danger")

    return render_template("login.html")


# Выход
@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Вы вышли из системы", "info")
    return redirect(url_for("home"))


# Словарь
@app.route("/vocabulary")
@login_required
def vocabulary():
    words = ChineseWord.query.all()
    return render_template("vocabulary.html", words=words)


# Добавление слова
@app.route("/add_word", methods=["POST"])
@login_required
def add_word():
    chinese = request.form.get("chinese_text")
    pinyin = request.form.get("pinyin")
    translation = request.form.get("translation")

    if chinese and translation:
        new_word = ChineseWord(chinese_text=chinese, pinyin=pinyin, translation=translation)
        database.session.add(new_word)
        database.session.commit()
        flash("Слово добавлено!", "success")

    return redirect(url_for('vocabulary'))


# Случайное слово
@app.route("/practice")
@login_required
def practice():
    words = ChineseWord.query.all()
    if not words:
        flash("Сначала добавьте слова в словарь", "warning")
        return redirect(url_for("vocabulary"))

    random_word = random.choice(words)
    return render_template("practice.html", word=random_word)


# Проверка ответа (API)
@app.route("/check_answer", methods=["POST"])
@login_required
def check_answer():
    data = request.get_json()
    word_id = data.get("word_id")
    user_answer = data.get("answer", '').strip().lower()

    word = ChineseWord.query.get(word_id)
    if word and user_answer == word.translation.lower():
        return jsonify({"correct": True, "message": "Правильно!"})
    else:
        return jsonify({"correct": False, "message": f"Неправильно. Правильный ответ: {word.translation}"})


# Апи
@app.route("/api/words")
def api_words():
    words = ChineseWord.query.all()
    return jsonify([{
        "id": w.id,
        "chinese": w.chinese_text,
        "pinyin": w.pinyin,
        "translation": w.translation
    } for w in words])


if __name__ == "__main__":
    with app.app_context():
        database.create_all()
    app.run(debug=True)